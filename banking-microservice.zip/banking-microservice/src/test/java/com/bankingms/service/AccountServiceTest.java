package com.bankingms.service;

import com.bankingms.dto.Dtos.CreateAccountRequest;
import com.bankingms.exception.AccountNotFoundException;
import com.bankingms.model.Account;
import com.bankingms.repository.AccountRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AccountServiceTest {

    @Mock
    private AccountRepository accountRepository;

    @InjectMocks
    private AccountService accountService;

    private CreateAccountRequest request;

    @BeforeEach
    void setUp() {
        request = new CreateAccountRequest();
        request.setOwnerName("Bikash Ghadai");
        request.setInitialDeposit(new BigDecimal("1000.00"));
    }

    @Test
    void createAccount_savesAndReturnsAccountWithGeneratedNumber() {
        when(accountRepository.existsByAccountNumber(any())).thenReturn(false);
        when(accountRepository.save(any(Account.class))).thenAnswer(inv -> inv.getArgument(0));

        Account result = accountService.createAccount(request);

        assertThat(result.getOwnerName()).isEqualTo("Bikash Ghadai");
        assertThat(result.getBalance()).isEqualByComparingTo("1000.00");
        assertThat(result.getAccountNumber()).startsWith("AC");
    }

    @Test
    void getAccount_throwsWhenNotFound() {
        when(accountRepository.findByAccountNumber("AC000000000")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> accountService.getAccount("AC000000000"))
                .isInstanceOf(AccountNotFoundException.class);
    }
}
