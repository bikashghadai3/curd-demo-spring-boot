package com.bankingms.repository;

import com.bankingms.model.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TransactionRepository extends JpaRepository<Transaction, String> {
    List<Transaction> findBySourceAccountNumberOrDestinationAccountNumber(String source, String destination);
}
