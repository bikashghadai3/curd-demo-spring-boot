package com.bankingms.kafka;

import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class NotificationEventListener {

    @KafkaListener(topics = "transaction-events", groupId = "notification-service")
    public void onTransactionEvent(TransactionEvent event) {
        // In a real system this would trigger an SMS/email/push notification.
        log.info("Notification service received event: txn={} type={} status={} amount={}",
                event.getTransactionId(), event.getType(), event.getStatus(), event.getAmount());
    }
}
