package com.bankingms.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;

public class Dtos {

    @Data
    public static class CreateAccountRequest {
        @NotBlank
        private String ownerName;

        @NotNull
        @DecimalMin(value = "0.0", inclusive = true)
        private BigDecimal initialDeposit;
    }

    @Data
    public static class DepositWithdrawRequest {
        @NotBlank
        private String accountNumber;

        @NotNull
        @DecimalMin(value = "0.01")
        private BigDecimal amount;
    }

    @Data
    public static class TransferRequest {
        @NotBlank
        private String sourceAccountNumber;

        @NotBlank
        private String destinationAccountNumber;

        @NotNull
        @DecimalMin(value = "0.01")
        private BigDecimal amount;
    }
}
