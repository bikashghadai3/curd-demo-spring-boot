package com.bankingms.service;

import com.bankingms.dto.Dtos.DepositWithdrawRequest;
import com.bankingms.dto.Dtos.TransferRequest;
import com.bankingms.exception.AccountNotFoundException;
import com.bankingms.exception.InsufficientFundsException;
import com.bankingms.kafka.TransactionEvent;
import com.bankingms.kafka.TransactionEventProducer;
import com.bankingms.model.Account;
import com.bankingms.model.Transaction;
import com.bankingms.repository.AccountRepository;
import com.bankingms.repository.TransactionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;

@Service
@RequiredArgsConstructor
public class TransactionService {

    private final AccountRepository accountRepository;
    private final TransactionRepository transactionRepository;
    private final TransactionEventProducer eventProducer;

    @Transactional
    public Transaction deposit(DepositWithdrawRequest request) {
        Account account = getAccountOrThrow(request.getAccountNumber());
        account.setBalance(account.getBalance().add(request.getAmount()));
        accountRepository.save(account);

        Transaction txn = saveTransaction(account.getAccountNumber(), null,
                request.getAmount(), Transaction.TransactionType.DEPOSIT);
        publishEvent(txn);
        return txn;
    }

    @Transactional
    public Transaction withdraw(DepositWithdrawRequest request) {
        Account account = getAccountOrThrow(request.getAccountNumber());
        if (account.getBalance().compareTo(request.getAmount()) < 0) {
            throw new InsufficientFundsException(account.getAccountNumber());
        }
        account.setBalance(account.getBalance().subtract(request.getAmount()));
        accountRepository.save(account);

        Transaction txn = saveTransaction(account.getAccountNumber(), null,
                request.getAmount(), Transaction.TransactionType.WITHDRAWAL);
        publishEvent(txn);
        return txn;
    }

    @Transactional
    public Transaction transfer(TransferRequest request) {
        Account source = getAccountOrThrow(request.getSourceAccountNumber());
        Account destination = getAccountOrThrow(request.getDestinationAccountNumber());

        if (source.getBalance().compareTo(request.getAmount()) < 0) {
            throw new InsufficientFundsException(source.getAccountNumber());
        }

        source.setBalance(source.getBalance().subtract(request.getAmount()));
        destination.setBalance(destination.getBalance().add(request.getAmount()));
        accountRepository.save(source);
        accountRepository.save(destination);

        Transaction txn = saveTransaction(source.getAccountNumber(), destination.getAccountNumber(),
                request.getAmount(), Transaction.TransactionType.TRANSFER);
        publishEvent(txn);
        return txn;
    }

    private Account getAccountOrThrow(String accountNumber) {
        return accountRepository.findByAccountNumber(accountNumber)
                .orElseThrow(() -> new AccountNotFoundException(accountNumber));
    }

    private Transaction saveTransaction(String source, String destination, BigDecimal amount,
                                         Transaction.TransactionType type) {
        Transaction txn = Transaction.builder()
                .sourceAccountNumber(source)
                .destinationAccountNumber(destination)
                .amount(amount)
                .type(type)
                .status(Transaction.TransactionStatus.COMPLETED)
                .build();
        return transactionRepository.save(txn);
    }

    private void publishEvent(Transaction txn) {
        TransactionEvent event = TransactionEvent.builder()
                .transactionId(txn.getId())
                .sourceAccountNumber(txn.getSourceAccountNumber())
                .destinationAccountNumber(txn.getDestinationAccountNumber())
                .amount(txn.getAmount())
                .type(txn.getType())
                .status(txn.getStatus())
                .timestamp(Instant.now().toString())
                .build();
        eventProducer.publish(event);
    }
}
