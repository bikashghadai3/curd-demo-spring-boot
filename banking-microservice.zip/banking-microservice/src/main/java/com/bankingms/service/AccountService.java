package com.bankingms.service;

import com.bankingms.dto.Dtos.CreateAccountRequest;
import com.bankingms.exception.AccountNotFoundException;
import com.bankingms.model.Account;
import com.bankingms.repository.AccountRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;

@Service
@RequiredArgsConstructor
public class AccountService {

    private final AccountRepository accountRepository;
    private static final SecureRandom RANDOM = new SecureRandom();

    @Transactional
    public Account createAccount(CreateAccountRequest request) {
        Account account = Account.builder()
                .accountNumber(generateAccountNumber())
                .ownerName(request.getOwnerName())
                .balance(request.getInitialDeposit())
                .status(Account.AccountStatus.ACTIVE)
                .build();
        return accountRepository.save(account);
    }

    public Account getAccount(String accountNumber) {
        return accountRepository.findByAccountNumber(accountNumber)
                .orElseThrow(() -> new AccountNotFoundException(accountNumber));
    }

    private String generateAccountNumber() {
        String candidate;
        do {
            candidate = "AC" + (100000000 + RANDOM.nextInt(900000000));
        } while (accountRepository.existsByAccountNumber(candidate));
        return candidate;
    }
}
