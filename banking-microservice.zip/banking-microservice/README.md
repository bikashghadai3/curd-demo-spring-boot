# Banking Transaction Processing Service

An event-driven backend microservice that handles bank account creation and
money movement (deposits, withdrawals, transfers), built with **Spring Boot**,
**Apache Kafka**, **PostgreSQL** and **Docker**.

Every completed transaction is published as an event to Kafka, where a
downstream notification listener consumes it — demonstrating an
asynchronous, decoupled microservice pattern commonly used in banking and
fintech systems.

## Architecture

```
Client
  │
  ▼
[REST API]  ── AccountController / TransactionController
  │
  ▼
[Service Layer] ── AccountService / TransactionService  (business rules, balance checks)
  │
  ├──▶ [PostgreSQL]  (accounts, transactions — source of truth)
  │
  └──▶ [Kafka: transaction-events topic]
              │
              ▼
      [NotificationEventListener]  (simulates SMS/email/push)
```

## Tech Stack

- Java 17, Spring Boot 3
- Spring Web, Spring Data JPA, Spring Validation
- Spring Kafka (producer + consumer)
- PostgreSQL (runtime), H2 (tests)
- springdoc-openapi (Swagger UI)
- Docker & Docker Compose (app + Kafka + Zookeeper + Postgres)
- JUnit 5, Mockito, AssertJ

## Features

- Create an account with an initial deposit
- Deposit / withdraw funds with balance validation
- Transfer funds between two accounts atomically
- Optimistic locking on account balance (`@Version`) to guard against
  concurrent update conflicts
- Every transaction emits a Kafka event consumed by a notification listener
- Centralized exception handling with meaningful HTTP status codes
- Interactive API docs via Swagger UI
- Actuator health/metrics endpoints

## Running locally with Docker Compose

```bash
docker compose up --build
```

This starts Postgres, Zookeeper, Kafka, and the service itself on port 8080.

Swagger UI: http://localhost:8080/swagger-ui.html
Health check: http://localhost:8080/actuator/health

## API Examples

**Create an account**
```bash
curl -X POST http://localhost:8080/api/v1/accounts \
  -H "Content-Type: application/json" \
  -d '{"ownerName":"Bikash Ghadai","initialDeposit":1000.00}'
```

**Deposit**
```bash
curl -X POST http://localhost:8080/api/v1/transactions/deposit \
  -H "Content-Type: application/json" \
  -d '{"accountNumber":"AC123456789","amount":250.00}'
```

**Transfer**
```bash
curl -X POST http://localhost:8080/api/v1/transactions/transfer \
  -H "Content-Type: application/json" \
  -d '{"sourceAccountNumber":"AC123456789","destinationAccountNumber":"AC987654321","amount":100.00}'
```

## Running tests

```bash
mvn test
```

## Suggested resume bullet points

- Designed and built an event-driven banking transaction microservice using
  Spring Boot and Apache Kafka, decoupling core ledger updates from
  downstream notification processing.
- Implemented optimistic-locking account balance updates and atomic
  transfer logic to prevent race conditions under concurrent load.
- Containerized the full stack (service, PostgreSQL, Kafka, Zookeeper) with
  Docker Compose for one-command local environment setup.
- Documented REST APIs with OpenAPI/Swagger and added centralized exception
  handling for consistent, predictable API error responses.

## Possible extensions

- Split into separate Account, Transaction and Notification microservices
  communicating purely over Kafka
- Add Spring Security / JWT auth
- Add an outbox table for guaranteed at-least-once event publishing
- Deploy to AWS (ECS/EKS) with Terraform
